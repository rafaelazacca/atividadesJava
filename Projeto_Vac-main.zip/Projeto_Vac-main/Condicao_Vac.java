package Project_Vac;

public interface Condicao_Vac {
	
	public int condicao(int i);

	
}
