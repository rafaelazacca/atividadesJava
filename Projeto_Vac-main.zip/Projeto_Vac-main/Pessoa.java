package Project_Vac;

public class Pessoa {

	private String nome;
	private String endere�o;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndere�o() {
		return endere�o;
	}
	public void setEndere�o(String endere�o) {
		this.endere�o = endere�o;
	}

	public void cadastro()
	{
		
	}

}
