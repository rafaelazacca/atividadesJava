package Project_Vac;

public class Alimentos {

}
